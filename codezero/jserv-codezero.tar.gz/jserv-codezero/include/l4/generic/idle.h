#ifndef __IDLE_H__
#define __IDLE_H__

void setup_idle_task(void);
void containers_setup_idle(void);


#endif
