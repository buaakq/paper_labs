#ifndef __PBA8_UART_H__
#define __PBA8_UART_H__

#include <l4/platform/realview/uart.h>

#endif /* __PBA8_UART_H__ */
