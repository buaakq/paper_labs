#ifndef __PB11MPCORE_UART_H__
#define __PB11MPCORE_UART_H__

#include <l4/platform/realview/uart.h>

#endif /* __PB11MPCORE_UART_H__ */
