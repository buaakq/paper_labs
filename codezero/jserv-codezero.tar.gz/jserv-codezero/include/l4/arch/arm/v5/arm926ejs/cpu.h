/*
 *
 * Copyright (C) 2005 Bahadir Balban
 *
 */
#ifndef __ARM926EJS__H__
#define __ARM926EJS__H__





#endif /* __ARM926EJS__H__ */
