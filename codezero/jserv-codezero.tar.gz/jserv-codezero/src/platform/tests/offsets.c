#include <macros.h>
#include <config.h>
#include INC_PLAT(offsets.h)

unsigned int PHYS_MEM_START = 0;	/* Dynamically allocated */
unsigned int PHYS_MEM_END = 0; 		/* Dynamically allocated */
unsigned int PHYS_ADDR_BASE = 0; 	/* Dynamically allocated */
