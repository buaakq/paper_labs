
#include <macros.h>
#include <config.h>
#include INC_ARCH(linker.h)
#include INC_PLAT(offsets.h)

unsigned int kernel_mapping_end = 0;
unsigned int _end = 0;
