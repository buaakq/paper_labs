/*
 * Kernel Interface Page
 *
 * Copyright (C) 2007, 2008 Bahadir Balban
 */
#include INC_API(kip.h)

SECTION(".data.kip") ALIGN(SZ_4K) struct kip kip;

