#ifndef __LIBPOSIX_INIT_H__
#define __LIBPOSIX_INIT_H__

int __libposix_init(void *envp);

#endif /* __LIBPOSIX_INIT_H__ */
