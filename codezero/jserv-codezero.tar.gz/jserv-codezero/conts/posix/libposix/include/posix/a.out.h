#ifdef _LIBC
# include_next <linux/a.out.h>
#else
# include <linux/a.out.h>
#endif
