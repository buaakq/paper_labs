#ifndef __MEMFS_FILE_H__
#define __MEMFS_FILE_H__

extern struct file_ops memfs_file_operations;
extern struct dentry_ops memfs_dentry_operations;

#endif /* __MEMFS_FILE_H__ */
