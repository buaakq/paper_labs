/*
 * Platform offsets for versatile express.
 *
 * Copyright (C) 2010 B Labs Ltd.
 *
 */
#ifndef __LIBDEV_PLATFORM_PBA9_H__
#define __LIBDEV_PLATFORM_PBA9_H__

#include <dev/platform/realview/platform.h>

#define PLATFORM_CLCD0_BASE		0x1001F000 /* CLCD */

#endif /* __LIBDEV_PLATFORM_PBA9_H__  */
