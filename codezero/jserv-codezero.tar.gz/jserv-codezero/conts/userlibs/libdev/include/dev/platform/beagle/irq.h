/*
 * IRQ numbers for beagle board.
 *
 * Copyright (C) 2010 B Labs Ltd.
 *
 */
#ifndef __LIBDEV_BEAGLE_IRQ_H__
#define __LIBDEV_BEAGLE_IRQ_H__

#define IRQ_TIMER0	37
#define IRQ_TIMER1	38

#endif /* __LIBDEV_BEAGLE_IRQ_H__  */
