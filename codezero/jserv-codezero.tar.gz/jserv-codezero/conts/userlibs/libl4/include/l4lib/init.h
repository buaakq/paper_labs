#ifndef __L4LIB_INIT__
#define __L4LIB_INIT__

void __l4_init(void);

#endif
