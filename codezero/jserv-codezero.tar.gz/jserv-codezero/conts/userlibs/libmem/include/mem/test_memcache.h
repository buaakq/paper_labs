#ifndef __TEST_MEMCACHE_H__
#define __TEST_MEMCACHE_H__

#include <mem/memcache.h>

int test_memcache(int num_alloc, int alloc_size_max, FILE *initstate, FILE *exitstate, int aligned);


#endif /* __TEST_MEMCACHE_H__ */

