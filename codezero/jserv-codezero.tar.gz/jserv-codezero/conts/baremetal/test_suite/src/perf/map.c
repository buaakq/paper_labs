/*
 * Copyright (C) 2010 B Labs Ltd.
 *
 * l4_map/l4_unmap performance tests
 *
 * Author: Bahadir Balban
 */

void perf_measure_map(void)
{

}

void perf_measure_unmap(void)
{

}
