/*
 * Copyright (C) 2010 B Labs Ltd.
 *
 * l4_ipc performance tests
 *
 * Author: Bahadir Balban
 */

void perf_measure_ipc(void)
{

}
