#ifndef __TEST_SUITE_LINKER_H__
#define __TEST_SUITE_LINKER_H__

extern unsigned char __stack[];
extern unsigned char __end[];
extern unsigned char vma_start[];
extern unsigned char lma_start[];
extern unsigned char offset[];
extern unsigned char __data_start[];
extern unsigned char __data_end[];
extern unsigned char __bss_start[];
extern unsigned char __bss_end[];
extern unsigned char __stack_start[];
extern unsigned char __stack_end[];

#endif /* __LINKER_H__ */
