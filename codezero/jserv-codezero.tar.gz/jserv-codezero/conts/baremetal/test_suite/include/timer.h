#ifndef __PERF_TESTS_TIMER_H__
#define __PERF_TESTS_TIMER_H__

#include <dev/timer.h>

extern unsigned long timer_base;
void perf_timer_init(void);

#endif /* __PERF_TESTS_TIMER_H__ */
