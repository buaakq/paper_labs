#ifndef __LINKER_H__
#define __LINKER_H__

extern char vma_start[];
extern char __end[];

#endif /* __LINKER_H__ */
