/*
 * Main function for this container
 */

#include <l4lib/macros.h>
#include L4LIB_INC_ARCH(syslib.h)
#include L4LIB_INC_ARCH(syscalls.h)
#include <l4/api/space.h>

extern int print_hello_world(void);

int main(void)
{
	print_hello_world();

	return 0;
}

